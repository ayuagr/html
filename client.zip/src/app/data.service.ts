import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private helper : HttpClient) { }

  getProducts(){
    return this.helper.get("http://192.168.43.221:9898/product")
  }
}
