import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  constructor(private service:DataService) { }
  products=[]
  ngOnInit() {
    this.service.getProducts().subscribe(result =>{
      if(result['status']==="success")
        this.products=result['data']
      else
        console.log('error',result['error'])
    })
  }

}
