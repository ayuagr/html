const mysql = require('mysql')

function connect(){
    const connection = mysql.createConnection({
        host : '192.168.43.221',
        user : 'root',
        password : 'root',
        database : 'mydb',
        port : 9094
    })

    connection.connect()
    return connection
}

module.exports = {
    connect:connect
}