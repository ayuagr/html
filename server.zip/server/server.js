const express = require('express')
const app = express()
const productRouter = require('./routes/products')

app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

app.use(express.json())

app.use('/product',productRouter)

app.get('/',(request,response)=>{
    response.send('welcome')
})

app.listen(9898,'0.0.0.0',()=>{
    console.log('server started at port 9898...')
})